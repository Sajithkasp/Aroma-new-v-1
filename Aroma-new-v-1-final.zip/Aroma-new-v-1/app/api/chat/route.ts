import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

/**
 * Chat API – reads Gemini/OpenAI key from:
 * 1. process.env.GEMINI_API_KEY or OPENAI_API_KEY (recommended)
 * 2. bot_settings.api_key in Supabase (admin editable)
 *
 * REPLACE in .env.local:
 *   GEMINI_API_KEY=your_key_here
 *   NEXT_PUBLIC_SUPABASE_URL=...
 *   NEXT_PUBLIC_SUPABASE_ANON_KEY=...
 *   SUPABASE_SERVICE_ROLE_KEY=... (optional, for reading api_key server-side)
 */

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const message: string = body.message || ''
    const history: { role: string; text: string }[] = body.history || []
    const botName: string = body.bot_name || 'Aroma Scent Sommelier'
    const model: string = body.model || 'gemini-2.0-flash'
    const temperature: number = Number(body.temperature ?? 0.7)

    if (!message.trim()) {
      return NextResponse.json({ error: 'Empty message' }, { status: 400 })
    }

    let apiKey =
      process.env.GEMINI_API_KEY ||
      process.env.GOOGLE_GENERATIVE_AI_API_KEY ||
      process.env.OPENAI_API_KEY ||
      ''

    // Optional: load key from bot_settings if env not set
    if (!apiKey) {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL
      const key =
        process.env.SUPABASE_SERVICE_ROLE_KEY ||
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
      if (url && key) {
        const sb = createClient(url, key)
        const { data } = await sb
          .from('bot_settings')
          .select('api_key, api_endpoint, model_name, welcome_message, default_fallback')
          .eq('is_active', true)
          .limit(1)
          .maybeSingle()
        if (data?.api_key) apiKey = data.api_key
      }
    }

    if (!apiKey) {
      return NextResponse.json(
        { error: 'API key not configured', reply: null },
        { status: 503 }
      )
    }

    const systemPrompt = `You are ${botName}, the expert fragrance concierge for Aroma Fine Perfumery, a luxury Sri Lankan brand based in Colombo. 
Help customers with scent notes (oud, cinnamon, aquatic), longevity, gifts, samples, delivery across Sri Lanka, and product recommendations.
Be elegant, warm, and concise (2–4 sentences). Prices are in LKR. Free delivery over LKR 10,000. Never invent fake medical claims.`

    const conversation = history
      .map((h) => `${h.role === 'user' ? 'Customer' : 'Sommelier'}: ${h.text}`)
      .join('\n')

    // Gemini REST
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`
    const geminiRes = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: `${systemPrompt}\n\nConversation so far:\n${conversation}\n\nCustomer: ${message}\nSommelier:`
              }
            ]
          }
        ],
        generationConfig: {
          temperature,
          maxOutputTokens: 400
        }
      })
    })

    if (!geminiRes.ok) {
      const errText = await geminiRes.text()
      console.error('Gemini error', errText)
      return NextResponse.json(
        { error: 'AI provider error', reply: null },
        { status: 502 }
      )
    }

    const geminiJson = await geminiRes.json()
    const reply =
      geminiJson?.candidates?.[0]?.content?.parts?.[0]?.text?.trim() ||
      'Thank you for your question. Our Colombo atelier team will assist you shortly.'

    return NextResponse.json({ reply })
  } catch (e: any) {
    console.error(e)
    return NextResponse.json(
      { error: e?.message || 'Server error', reply: null },
      { status: 500 }
    )
  }
}
