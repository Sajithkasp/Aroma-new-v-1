'use client'

import { useEffect, useState } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { AROMA_FRAGRANCES, Fragrance } from '@/lib/aromaData'
import { supabase } from '@/lib/supabase'
import { useCart } from '@/lib/cartContext'
import { avatarFromEmail } from '@/lib/config'
import {
  Star,
  ArrowLeft,
  ShoppingBag,
  Check,
  ShieldCheck,
  Truck
} from 'lucide-react'

interface ReviewRow {
  id: string
  customer_name: string
  customer_email?: string
  rating: number
  title?: string
  comment: string
  is_approved?: boolean
  created_at?: string
}

export default function ProductPage() {
  const params = useParams()
  const slug = String(params?.slug || '')
  const { addToCart } = useCart()
  const [product, setProduct] = useState<Fragrance | null>(null)
  const [reviews, setReviews] = useState<ReviewRow[]>([])
  const [volume, setVolume] = useState(50)
  const [added, setAdded] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      setLoading(true)
      try {
        const { data } = await supabase
          .from('products')
          .select('*')
          .eq('slug', slug)
          .eq('is_active', true)
          .maybeSingle()

        if (data) {
          const fallback = AROMA_FRAGRANCES.find((f) => f.slug === slug) || AROMA_FRAGRANCES[0]
          setProduct({
            ...fallback,
            id: String(data.id),
            name: data.name || fallback.name,
            slug: data.slug || slug,
            price: Number(data.price || fallback.price),
            compare_price: data.compare_price ? Number(data.compare_price) : fallback.compare_price,
            description: data.description || fallback.description,
            image_url: data.image_url || fallback.image_url,
            fragrance_notes: data.fragrance_notes || fallback.fragrance_notes,
            volume_ml: Number(data.volume_ml || 50),
            stock: Number(data.stock || 25)
          })
          setVolume(Number(data.volume_ml || 50))
        } else {
          const local = AROMA_FRAGRANCES.find((f) => f.slug === slug) || null
          setProduct(local)
          if (local) setVolume(local.volume_ml)
        }

        const { data: rev } = await supabase
          .from('reviews')
          .select('*')
          .eq('product_id', data?.id || slug)
          .eq('is_approved', true)
          .order('created_at', { ascending: false })
          .limit(20)

        if (rev && rev.length) setReviews(rev as ReviewRow[])
      } catch {
        const local = AROMA_FRAGRANCES.find((f) => f.slug === slug) || null
        setProduct(local)
      } finally {
        setLoading(false)
      }
    }
    if (slug) load()
  }, [slug])

  const handleAdd = () => {
    if (!product) return
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      volume_ml: volume,
      image_url: product.image_url,
      concentration: product.concentration
    })
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center text-neutral-400 font-mono text-sm">
        Loading fragrance...
      </div>
    )
  }

  if (!product) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-24 text-center">
        <p className="text-neutral-400 mb-6">Fragrance not found.</p>
        <Link href="/" className="text-amber-400 hover:underline text-sm">
          ← Back to catalog
        </Link>
      </div>
    )
  }

  const avgRating =
    reviews.length > 0
      ? reviews.reduce((s, r) => s + Number(r.rating || 0), 0) / reviews.length
      : product.rating

  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <Link
        href="/#fragrance-catalog"
        className="inline-flex items-center gap-2 text-xs font-mono text-neutral-400 hover:text-amber-300 mb-8"
      >
        <ArrowLeft className="w-3.5 h-3.5" /> Catalog
      </Link>

      <div className="grid lg:grid-cols-2 gap-12">
        <div className="aspect-square rounded-3xl overflow-hidden border border-neutral-800 bg-neutral-900">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={product.image_url}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </div>

        <div>
          <p className="text-[10px] font-mono tracking-[0.3em] text-amber-400 uppercase mb-2">
            {product.category} · {product.concentration}
          </p>
          <h1 className="text-4xl font-serif text-white mb-2">{product.name}</h1>
          <p className="text-neutral-400 text-sm mb-4">{product.subtitle}</p>

          <div className="flex items-center gap-2 mb-6">
            <div className="flex text-amber-400">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`w-4 h-4 ${i < Math.round(avgRating) ? 'fill-amber-400' : ''}`}
                />
              ))}
            </div>
            <span className="text-xs text-neutral-400 font-mono">
              {avgRating.toFixed(1)} · {reviews.length || product.reviews_count} reviews
            </span>
          </div>

          <div className="flex items-baseline gap-3 mb-6">
            <span className="text-3xl font-mono text-amber-300">
              LKR {product.price.toLocaleString()}
            </span>
            {product.compare_price && product.compare_price > product.price && (
              <span className="text-neutral-500 line-through font-mono text-sm">
                LKR {product.compare_price.toLocaleString()}
              </span>
            )}
          </div>

          <p className="text-neutral-300 text-sm leading-relaxed mb-6">
            {product.description}
          </p>

          <p className="text-xs font-mono text-neutral-500 mb-2">Notes</p>
          <p className="text-sm text-neutral-300 mb-8">{product.fragrance_notes}</p>

          {product.volume_options?.length > 0 && (
            <div className="flex gap-2 mb-6">
              {product.volume_options.map((v) => (
                <button
                  key={v}
                  onClick={() => setVolume(v)}
                  className={`px-4 py-2 rounded-xl text-xs font-mono border transition ${
                    volume === v
                      ? 'border-amber-400 bg-amber-400/10 text-amber-300'
                      : 'border-neutral-800 text-neutral-400 hover:border-neutral-600'
                  }`}
                >
                  {v} ml
                </button>
              ))}
            </div>
          )}

          <button
            onClick={handleAdd}
            className="w-full sm:w-auto px-8 py-4 rounded-xl bg-white text-black font-bold text-xs uppercase tracking-wider hover:bg-neutral-200 transition flex items-center justify-center gap-2"
          >
            {added ? (
              <>
                <Check className="w-4 h-4" /> Added to Bag
              </>
            ) : (
              <>
                <ShoppingBag className="w-4 h-4" /> Add to Bag
              </>
            )}
          </button>

          <div className="flex flex-wrap gap-4 mt-6 text-[11px] text-neutral-500">
            <span className="flex items-center gap-1">
              <Truck className="w-3.5 h-3.5 text-amber-400" /> Island-wide delivery
            </span>
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Authentic guarantee
            </span>
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-20 border-t border-neutral-900 pt-12">
        <h2 className="text-2xl font-serif mb-8">Customer Reviews</h2>
        {reviews.length === 0 ? (
          <p className="text-neutral-500 text-sm">
            No approved reviews yet. Be the first after your order.
          </p>
        ) : (
          <div className="space-y-6">
            {reviews.map((r) => (
              <div
                key={r.id}
                className="flex gap-4 p-5 rounded-2xl border border-neutral-800 bg-neutral-950/50"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={avatarFromEmail(r.customer_email || r.customer_name)}
                  alt={r.customer_name}
                  className="w-12 h-12 rounded-full border border-neutral-700 shrink-0"
                />
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-white text-sm">{r.customer_name}</span>
                    <div className="flex text-amber-400">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3 h-3 ${i < r.rating ? 'fill-amber-400' : ''}`}
                        />
                      ))}
                    </div>
                  </div>
                  {r.title && (
                    <p className="text-xs font-mono text-amber-300/80 mb-1">{r.title}</p>
                  )}
                  <p className="text-sm text-neutral-300 leading-relaxed">{r.comment}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  )
}
