'use client'

import { useEffect, useState, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import { MessageCircle, X, Send, Sparkles, Loader2 } from 'lucide-react'

interface BotSettings {
  bot_name: string
  button_label: string
  button_subtitle: string
  welcome_message: string
  default_fallback: string
  model_name: string
  temperature: number
  api_key?: string
  api_endpoint?: string
  is_active: boolean
}

interface ChatMessage {
  role: 'user' | 'bot'
  text: string
}

const DEFAULTS: BotSettings = {
  bot_name: 'Aroma Scent Sommelier',
  button_label: 'Ask Aroma',
  button_subtitle: 'Scent Concierge',
  welcome_message:
    'Greetings! I am your personal Aroma fragrance concierge. What mood or occasion are you shopping for today?',
  default_fallback:
    'I would be delighted to connect you with our boutique perfumer in Colombo. May I have your WhatsApp number or email?',
  model_name: 'gemini-2.5-flash',
  temperature: 0.7,
  is_active: true
}

export default function AskAromaBot() {
  const [settings, setSettings] = useState<BotSettings>(DEFAULTS)
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [loading, setLoading] = useState(false)
  const [loaded, setLoaded] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const load = async () => {
      try {
        const { data, error } = await supabase
          .from('bot_settings')
          .select('*')
          .eq('is_active', true)
          .limit(1)
          .maybeSingle()

        if (!error && data) {
          setSettings({
            bot_name: data.bot_name || DEFAULTS.bot_name,
            button_label: data.button_label || DEFAULTS.button_label,
            button_subtitle: data.button_subtitle || DEFAULTS.button_subtitle,
            welcome_message: data.welcome_message || DEFAULTS.welcome_message,
            default_fallback: data.default_fallback || DEFAULTS.default_fallback,
            model_name: data.model_name || DEFAULTS.model_name,
            temperature: Number(data.temperature ?? DEFAULTS.temperature),
            api_key: data.api_key || '',
            api_endpoint: data.api_endpoint || '',
            is_active: data.is_active !== false
          })
        }
      } catch {
        // keep defaults
      } finally {
        setLoaded(true)
      }
    }
    load()
  }, [])

  useEffect(() => {
    if (open && messages.length === 0) {
      setMessages([{ role: 'bot', text: settings.welcome_message }])
    }
  }, [open, settings.welcome_message, messages.length])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, loading])

  const sendMessage = async () => {
    const text = input.trim()
    if (!text || loading) return
    setInput('')
    setMessages((prev) => [...prev, { role: 'user', text }])
    setLoading(true)

    try {
      // Prefer server route if API key is configured in bot_settings
      // Client calls /api/chat which reads key from env or (securely) server-side only
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: messages.slice(-8),
          bot_name: settings.bot_name,
          model: settings.model_name,
          temperature: settings.temperature
        })
      })

      if (res.ok) {
        const data = await res.json()
        setMessages((prev) => [
          ...prev,
          { role: 'bot', text: data.reply || settings.default_fallback }
        ])
      } else {
        // Fallback local replies when API not configured
        const lower = text.toLowerCase()
        let reply = settings.default_fallback
        if (lower.includes('oud') || lower.includes('royal')) {
          reply =
            'Our Ceylon Royal Oud (Extrait 35%) delivers 16+ hour longevity with aged agarwood and Ceylon cinnamon. Would you like a 3ml sample with your order?'
        } else if (lower.includes('gift') || lower.includes('sample')) {
          reply =
            'Every full-size order includes 2 complimentary 3ml bespoke samples. Gift wrapping is available at checkout.'
        } else if (lower.includes('delivery') || lower.includes('shipping')) {
          reply =
            'We offer island-wide express courier. Free delivery on orders over LKR 10,000. Most Colombo orders arrive within 24–48 hours.'
        } else if (lower.includes('price') || lower.includes('cost')) {
          reply =
            'Our Extrait collection starts from LKR 13,500. You can filter by concentration and notes in the catalog.'
        }
        setMessages((prev) => [...prev, { role: 'bot', text: reply }])
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: 'bot', text: settings.default_fallback }
      ])
    } finally {
      setLoading(false)
    }
  }

  if (!loaded || !settings.is_active) return null

  return (
    <>
      {/* Floating button – bottom right */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-6 right-6 z-[60] group flex items-center gap-3 pl-4 pr-5 py-3 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 text-black shadow-2xl shadow-amber-500/30 hover:from-amber-400 hover:to-amber-500 transition-all hover:scale-105"
          aria-label={settings.button_label}
        >
          <span className="w-10 h-10 rounded-full bg-black/15 flex items-center justify-center">
            <MessageCircle className="w-5 h-5" />
          </span>
          <span className="text-left hidden sm:block">
            <span className="block text-sm font-bold leading-tight">
              {settings.button_label}
            </span>
            <span className="block text-[10px] font-medium opacity-80 uppercase tracking-wider">
              {settings.button_subtitle}
            </span>
          </span>
          <Sparkles className="w-4 h-4 opacity-70 group-hover:opacity-100" />
        </button>
      )}

      {/* Chat panel */}
      {open && (
        <div className="fixed bottom-6 right-6 z-[60] w-[min(100vw-2rem,380px)] h-[min(70vh,520px)] flex flex-col rounded-2xl border border-neutral-800 bg-[#0c0c0c] shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-neutral-800 bg-gradient-to-r from-neutral-900 to-[#0c0c0c]">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-amber-400/15 border border-amber-400/40 flex items-center justify-center text-amber-300">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-semibold text-white leading-tight">
                  {settings.bot_name}
                </p>
                <p className="text-[10px] text-emerald-400 font-mono">Online · Aroma</p>
              </div>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="p-2 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800 transition"
              aria-label="Close chat"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
                    m.role === 'user'
                      ? 'bg-amber-500 text-black rounded-br-md'
                      : 'bg-neutral-900 border border-neutral-800 text-neutral-200 rounded-bl-md'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-neutral-900 border border-neutral-800 rounded-2xl rounded-bl-md px-4 py-3 text-neutral-400">
                  <Loader2 className="w-4 h-4 animate-spin" />
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          <div className="p-3 border-t border-neutral-800 bg-[#0a0a0a]">
            <form
              onSubmit={(e) => {
                e.preventDefault()
                sendMessage()
              }}
              className="flex items-center gap-2"
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about notes, gifts, delivery..."
                className="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder:text-neutral-500 focus:outline-none focus:border-amber-500/50"
              />
              <button
                type="submit"
                disabled={loading || !input.trim()}
                className="p-2.5 rounded-xl bg-amber-500 text-black hover:bg-amber-400 disabled:opacity-40 transition"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  )
}
