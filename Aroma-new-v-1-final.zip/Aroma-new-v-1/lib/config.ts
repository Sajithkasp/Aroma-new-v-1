/**
 * Aroma Store – Global Config
 * REPLACE: Admin email is locked to the owner. Change only if ownership transfers.
 */
export const ADMIN_EMAILS = ['sajith.kasp@gmail.com'] as const

export function isAdminEmail(email: string | null | undefined): boolean {
  if (!email) return false
  return ADMIN_EMAILS.includes(email.trim().toLowerCase() as (typeof ADMIN_EMAILS)[number])
}

/** Gravatar from email (reviews avatar) */
export function avatarFromEmail(email: string | null | undefined, size = 80): string {
  if (!email) return `https://ui-avatars.com/api/?name=Guest&background=1a1a1a&color=d4af37&size=${size}`
  // Simple deterministic avatar without crypto dependency
  let hash = 0
  const normalized = email.trim().toLowerCase()
  for (let i = 0; i < normalized.length; i++) {
    hash = (hash << 5) - hash + normalized.charCodeAt(i)
    hash |= 0
  }
  const name = encodeURIComponent(normalized.split('@')[0] || 'Customer')
  return `https://ui-avatars.com/api/?name=${name}&background=1a1a1a&color=d4af37&size=${size}&bold=true`
}

export const FREE_DELIVERY_THRESHOLD = 10000
export const DEFAULT_CURRENCY = 'LKR'
